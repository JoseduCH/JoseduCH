create_clock -period 20.0 -name vclk [get_ports clk_i]

set_input_delay -clock vclk 2.0 \
[get_ports {x_i[*] y_i[*] zx_i nx_i zy_i ny_i f_i no_i}]

set_output_delay -clock vclk 2.0 \
[get_ports {out_o[*] zr_o ng_o pos_o}]

set_false_path -from [get_ports rst_i]